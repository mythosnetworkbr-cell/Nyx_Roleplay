# 📱 RPGRAM

**RPGRAM** é uma rede social mobile criada para comunidades de **Roleplay**.

> MVP inicial inspirado na experiência de redes sociais modernas, com identidade própria para servidores RP.

## ✨ Funcionalidades atuais

- 🔐 Login e cadastro
- 🏠 Feed de publicações
- ❤️ Curtidas
- 🔎 Pesquisa de jogadores
- ➕ Publicação de fotos
- 👤 Perfil
- 🔔 Atividade
- 📱 Navegação mobile
- 🗄️ Estrutura Supabase
- 🔒 Row Level Security (RLS)
- 📦 Configuração para geração de APK

## 🧰 Tecnologias

- React Native
- Expo
- TypeScript
- Supabase
- Expo Image Picker

## 🚀 Instalação

```bash
npm install
```

Crie um arquivo `.env` baseado em `.env.example`:

```env
EXPO_PUBLIC_SUPABASE_URL=https://SEU-PROJETO.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=SUA_CHAVE_PUBLICAVEL
```

No Supabase, execute:

```text
supabase/schema.sql
```

Depois:

```bash
npx expo start
```

## 📦 Gerar APK

Instale o EAS CLI:

```bash
npm install -g eas-cli
```

Faça login:

```bash
eas login
```

Configure o projeto:

```bash
eas build:configure
```

Gere o APK de teste:

```bash
eas build -p android --profile preview
```

## 🗂️ Estrutura

```text
RPGRAM/
├── .github/
├── assets/
├── lib/
│   └── supabase.ts
├── supabase/
│   └── schema.sql
├── .env.example
├── .gitignore
├── App.tsx
├── app.json
├── eas.json
├── package.json
├── tsconfig.json
└── README.md
```

## 🔐 Segurança

Nunca publique chaves privadas, senhas ou arquivos `.env`.

Use apenas a chave pública/publishable do Supabase no aplicativo e mantenha regras de acesso protegidas por RLS.

## 🛣️ Roadmap

- [ ] Feed conectado ao banco
- [ ] Upload real no Storage
- [ ] Comentários
- [ ] Seguidores/seguindo
- [ ] Chat privado
- [ ] Stories
- [ ] Notificações push
- [ ] Perfis de personagens
- [ ] Sistema de servidores RP
- [ ] Denúncias e moderação
- [ ] Painel administrativo
- [ ] Perfil verificado
- [ ] Sistema de hashtags
- [ ] Busca avançada
- [ ] Publicação de vídeos
- [ ] Preparação para Play Store

## 📄 Licença

Projeto RPGRAM — uso conforme a licença definida pelo proprietário do repositório.
