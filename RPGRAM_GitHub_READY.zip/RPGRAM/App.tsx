import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, Image, KeyboardAvoidingView,
  Platform, Pressable, SafeAreaView, ScrollView, StatusBar, StyleSheet,
  Text, TextInput, View
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';

type Tab = 'home' | 'search' | 'create' | 'activity' | 'profile';

type Post = {
  id: string;
  author: string;
  handle: string;
  avatar: string;
  image: string;
  caption: string;
  likes: number;
  comments: number;
  liked?: boolean;
};

const DEMO_POSTS: Post[] = [
  {
    id: '1', author: 'Alex Costa', handle: '@alexrp',
    avatar: 'https://i.pravatar.cc/150?img=12',
    image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=1000',
    caption: 'Hoje o RP foi insano. Quem estava na cidade? 🔥',
    likes: 1245, comments: 86
  },
  {
    id: '2', author: 'Luna Martins', handle: '@lunam',
    avatar: 'https://i.pravatar.cc/150?img=47',
    image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1000',
    caption: 'Encontrando a galera antes do início da operação. 👀',
    likes: 893, comments: 41
  }
];

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [booting, setBooting] = useState(true);
  const [tab, setTab] = useState<Tab>('home');
  const [posts, setPosts] = useState<Post[]>(DEMO_POSTS);
  const [search, setSearch] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [caption, setCaption] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    if (!supabase) {
      setBooting(false);
      return;
    }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setBooting(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function authenticate() {
    if (!email || !password) return Alert.alert('RPGRAM', 'Informe e-mail e senha.');
    if (!supabase) {
      setSession({ user: { email } });
      return;
    }
    const result = authMode === 'login'
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password });
    if (result.error) Alert.alert('Erro', result.error.message);
    else if (authMode === 'signup') Alert.alert('RPGRAM', 'Cadastro criado. Confirme seu e-mail se solicitado.');
  }

  async function pickImage() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Permissão', 'Permita acesso às fotos para criar uma publicação.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.85,
      allowsEditing: true,
      aspect: [1, 1]
    });
    if (!result.canceled) setSelectedImage(result.assets[0].uri);
  }

  function publish() {
    if (!selectedImage) return Alert.alert('RPGRAM', 'Escolha uma imagem.');
    const newPost: Post = {
      id: Date.now().toString(),
      author: session?.user?.email?.split('@')[0] || 'Jogador',
      handle: '@jogador',
      avatar: 'https://i.pravatar.cc/150?img=33',
      image: selectedImage,
      caption: caption || 'Nova publicação no RPGRAM! 🎮',
      likes: 0, comments: 0
    };
    setPosts(current => [newPost, ...current]);
    setCaption('');
    setSelectedImage(null);
    setTab('home');
  }

  function toggleLike(id: string) {
    setPosts(current => current.map(p =>
      p.id === id
        ? { ...p, liked: !p.liked, likes: p.likes + (p.liked ? -1 : 1) }
        : p
    ));
  }

  if (booting) return <Splash />;

  if (!session) {
    return (
      <AuthScreen
        email={email} password={password}
        setEmail={setEmail} setPassword={setPassword}
        mode={authMode} setMode={setAuthMode}
        onSubmit={authenticate}
      />
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" />
      {tab === 'home' && <Home posts={posts} onLike={toggleLike} />}
      {tab === 'search' && <Search search={search} setSearch={setSearch} />}
      {tab === 'create' && (
        <Create
          selectedImage={selectedImage}
          caption={caption}
          setCaption={setCaption}
          onPick={pickImage}
          onPublish={publish}
        />
      )}
      {tab === 'activity' && <Activity />}
      {tab === 'profile' && (
        <Profile
          session={session}
          postCount={posts.length}
          onLogout={async () => {
            if (supabase) await supabase.auth.signOut();
            else setSession(null);
          }}
        />
      )}
      <BottomBar tab={tab} setTab={setTab} />
    </SafeAreaView>
  );
}

function Splash() {
  return <View style={styles.splash}><Text style={styles.logo}>RPGRAM</Text><ActivityIndicator /></View>;
}

function AuthScreen(props: any) {
  return (
    <KeyboardAvoidingView style={styles.auth} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View>
        <Text style={styles.logo}>RPGRAM</Text>
        <Text style={styles.tagline}>A rede social do seu Roleplay.</Text>
        <TextInput style={styles.input} placeholder="E-mail" placeholderTextColor="#777" autoCapitalize="none" keyboardType="email-address" value={props.email} onChangeText={props.setEmail} />
        <TextInput style={styles.input} placeholder="Senha" placeholderTextColor="#777" secureTextEntry value={props.password} onChangeText={props.setPassword} />
        <Pressable style={styles.primary} onPress={props.onSubmit}>
          <Text style={styles.primaryText}>{props.mode === 'login' ? 'Entrar' : 'Criar conta'}</Text>
        </Pressable>
        <Pressable onPress={() => props.setMode(props.mode === 'login' ? 'signup' : 'login')}>
          <Text style={styles.switch}>{props.mode === 'login' ? 'Ainda não tenho conta' : 'Já tenho uma conta'}</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

function Home({ posts, onLike }: { posts: Post[]; onLike: (id: string) => void }) {
  return (
    <FlatList
      data={posts}
      keyExtractor={item => item.id}
      contentContainerStyle={{ paddingBottom: 90 }}
      ListHeaderComponent={
        <View style={styles.header}>
          <Text style={styles.headerLogo}>RPGRAM</Text>
          <View style={styles.headerIcons}>
            <Ionicons name="notifications-outline" size={25} color="#fff" />
            <Ionicons name="chatbubble-ellipses-outline" size={24} color="#fff" />
          </View>
        </View>
      }
      renderItem={({ item }) => (
        <View style={styles.post}>
          <View style={styles.postHeader}>
            <Image source={{ uri: item.avatar }} style={styles.avatar} />
            <View><Text style={styles.author}>{item.author}</Text><Text style={styles.handle}>{item.handle}</Text></View>
            <Ionicons name="ellipsis-horizontal" size={20} color="#aaa" style={{ marginLeft: 'auto' }} />
          </View>
          <Image source={{ uri: item.image }} style={styles.postImage} />
          <View style={styles.postActions}>
            <Pressable onPress={() => onLike(item.id)}>
              <Ionicons name={item.liked ? 'heart' : 'heart-outline'} size={29} color={item.liked ? '#ff315d' : '#fff'} />
            </Pressable>
            <Ionicons name="chatbubble-outline" size={26} color="#fff" />
            <Ionicons name="paper-plane-outline" size={27} color="#fff" />
            <Ionicons name="bookmark-outline" size={26} color="#fff" style={{ marginLeft: 'auto' }} />
          </View>
          <Text style={styles.likes}>{item.likes.toLocaleString('pt-BR')} curtidas</Text>
          <Text style={styles.caption}><Text style={{ fontWeight: '800' }}>{item.handle} </Text>{item.caption}</Text>
          <Text style={styles.comments}>Ver {item.comments} comentários</Text>
        </View>
      )}
    />
  );
}

function Search({ search, setSearch }: any) {
  const users = ['@alexrp', '@lunam', '@zoro', '@medusa', '@floriparp'];
  const filtered = users.filter((u: string) => u.toLowerCase().includes(search.toLowerCase()));
  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Pesquisar</Text>
      <View style={styles.searchBox}>
        <Ionicons name="search" size={20} color="#777" />
        <TextInput value={search} onChangeText={setSearch} placeholder="Jogadores, servidores..." placeholderTextColor="#777" style={{ flex: 1, color: '#fff' }} />
      </View>
      {filtered.map((u: string) => <View key={u} style={styles.searchRow}><Image source={{ uri: `https://i.pravatar.cc/100?u=${u}` }} style={styles.avatar} /><Text style={styles.author}>{u}</Text></View>)}
    </View>
  );
}

function Create({ selectedImage, caption, setCaption, onPick, onPublish }: any) {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ paddingBottom: 110 }}>
      <Text style={styles.title}>Nova publicação</Text>
      <Pressable style={styles.imagePicker} onPress={onPick}>
        {selectedImage ? <Image source={{ uri: selectedImage }} style={styles.preview} /> :
          <><Ionicons name="images-outline" size={45} color="#aaa" /><Text style={styles.muted}>Escolher foto</Text></>}
      </Pressable>
      <TextInput style={[styles.input, { height: 110, textAlignVertical: 'top' }]} multiline placeholder="Escreva uma legenda..." placeholderTextColor="#777" value={caption} onChangeText={setCaption} />
      <Pressable style={styles.primary} onPress={onPublish}><Text style={styles.primaryText}>Publicar no RPGRAM</Text></Pressable>
    </ScrollView>
  );
}

function Activity() {
  return <View style={styles.screen}><Text style={styles.title}>Atividade</Text><Text style={styles.activity}>❤️ Alex curtiu sua publicação</Text><Text style={styles.activity}>💬 Luna comentou na sua foto</Text><Text style={styles.activity}>👤 Zoro começou a seguir você</Text></View>;
}

function Profile({ session, postCount, onLogout }: any) {
  const name = session?.user?.email?.split('@')[0] || 'Jogador';
  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ paddingBottom: 110 }}>
      <View style={styles.profileTop}>
        <Image source={{ uri: 'https://i.pravatar.cc/200?img=33' }} style={styles.profileAvatar} />
        <View style={{ flex: 1 }}>
          <Text style={styles.profileName}>{name}</Text>
          <Text style={styles.handle}>@{name}</Text>
          <Text style={styles.bio}>Jogador de Roleplay 🎮</Text>
        </View>
      </View>
      <View style={styles.stats}>
        <Stat value={String(postCount)} label="posts" />
        <Stat value="1.2K" label="seguidores" />
        <Stat value="438" label="seguindo" />
      </View>
      <Pressable style={styles.secondary}><Text style={styles.secondaryText}>Editar perfil</Text></Pressable>
      <Pressable style={styles.logout} onPress={onLogout}><Text style={styles.logoutText}>Sair da conta</Text></Pressable>
    </ScrollView>
  );
}

function Stat({ value, label }: any) {
  return <View style={{ alignItems: 'center', flex: 1 }}><Text style={styles.statValue}>{value}</Text><Text style={styles.handle}>{label}</Text></View>;
}

function BottomBar({ tab, setTab }: { tab: Tab; setTab: (t: Tab) => void }) {
  const items: [Tab, any][] = [
    ['home', 'home-outline'], ['search', 'search-outline'], ['create', 'add-circle-outline'], ['activity', 'heart-outline'], ['profile', 'person-outline']
  ];
  return (
    <View style={styles.bottom}>
      {items.map(([key, icon]) => <Pressable key={key} onPress={() => setTab(key)} style={styles.tab}>
        <Ionicons name={key === tab ? icon.replace('-outline', '') as any : icon} size={27} color={key === tab ? '#fff' : '#777'} />
      </Pressable>)}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#09090B' },
  splash: { flex: 1, backgroundColor: '#09090B', alignItems: 'center', justifyContent: 'center', gap: 20 },
  logo: { color: '#fff', fontSize: 42, fontWeight: '900', letterSpacing: -2 },
  tagline: { color: '#999', fontSize: 15, marginTop: 8, marginBottom: 35, textAlign: 'center' },
  auth: { flex: 1, backgroundColor: '#09090B', justifyContent: 'center', padding: 28 },
  input: { backgroundColor: '#17171A', color: '#fff', borderRadius: 12, padding: 15, marginBottom: 12, borderWidth: 1, borderColor: '#252529' },
  primary: { backgroundColor: '#fff', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 5 },
  primaryText: { color: '#09090B', fontWeight: '900', fontSize: 15 },
  switch: { color: '#aaa', textAlign: 'center', marginTop: 22 },
  header: { height: 65, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#19191D' },
  headerLogo: { color: '#fff', fontSize: 24, fontWeight: '900' },
  headerIcons: { marginLeft: 'auto', flexDirection: 'row', gap: 18 },
  post: { borderBottomWidth: 1, borderBottomColor: '#19191D', paddingBottom: 18 },
  postHeader: { flexDirection: 'row', alignItems: 'center', padding: 13 },
  avatar: { width: 42, height: 42, borderRadius: 21, marginRight: 11 },
  author: { color: '#fff', fontWeight: '800', fontSize: 14 },
  handle: { color: '#888', fontSize: 12, marginTop: 2 },
  postImage: { width: '100%', aspectRatio: 1, backgroundColor: '#151518' },
  postActions: { flexDirection: 'row', alignItems: 'center', gap: 17, padding: 12 },
  likes: { color: '#fff', fontWeight: '800', paddingHorizontal: 13 },
  caption: { color: '#ddd', lineHeight: 20, paddingHorizontal: 13, paddingTop: 6 },
  comments: { color: '#777', paddingHorizontal: 13, paddingTop: 8 },
  bottom: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 70, backgroundColor: '#0B0B0D', borderTopWidth: 1, borderTopColor: '#222', flexDirection: 'row' },
  tab: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  screen: { flex: 1, padding: 18, backgroundColor: '#09090B' },
  title: { color: '#fff', fontSize: 28, fontWeight: '900', marginBottom: 20 },
  searchBox: { flexDirection: 'row', gap: 8, alignItems: 'center', backgroundColor: '#17171A', borderRadius: 12, paddingHorizontal: 13, marginBottom: 20 },
  searchRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10 },
  imagePicker: { height: 330, borderRadius: 18, borderWidth: 1, borderColor: '#2A2A2E', borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 16 },
  preview: { width: '100%', height: '100%' },
  muted: { color: '#888', marginTop: 10 },
  activity: { color: '#ddd', paddingVertical: 18, borderBottomWidth: 1, borderBottomColor: '#1D1D21' },
  profileTop: { flexDirection: 'row', alignItems: 'center', gap: 18, marginBottom: 24 },
  profileAvatar: { width: 88, height: 88, borderRadius: 44 },
  profileName: { color: '#fff', fontSize: 23, fontWeight: '900' },
  bio: { color: '#aaa', marginTop: 7 },
  stats: { flexDirection: 'row', marginBottom: 18 },
  statValue: { color: '#fff', fontSize: 19, fontWeight: '900' },
  secondary: { borderWidth: 1, borderColor: '#333', borderRadius: 10, padding: 13, alignItems: 'center' },
  secondaryText: { color: '#fff', fontWeight: '800' },
  logout: { marginTop: 25, padding: 15, alignItems: 'center' },
  logoutText: { color: '#ff496b', fontWeight: '800' }
});