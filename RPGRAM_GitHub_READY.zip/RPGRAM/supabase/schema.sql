-- RPGRAM database
create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default '',
  bio text not null default '',
  avatar_url text,
  server_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  image_url text not null,
  caption text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  user_id uuid not null references auth.users(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid not null references auth.users(id) on delete cascade,
  following_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  type text not null,
  post_id uuid references public.posts(id) on delete cascade,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.notifications enable row level security;

create policy "profiles readable" on public.profiles for select using (true);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);

create policy "posts readable" on public.posts for select using (true);
create policy "own posts insert" on public.posts for insert with check (auth.uid() = user_id);
create policy "own posts update" on public.posts for update using (auth.uid() = user_id);
create policy "own posts delete" on public.posts for delete using (auth.uid() = user_id);

create policy "likes readable" on public.likes for select using (true);
create policy "own likes insert" on public.likes for insert with check (auth.uid() = user_id);
create policy "own likes delete" on public.likes for delete using (auth.uid() = user_id);

create policy "comments readable" on public.comments for select using (true);
create policy "own comments insert" on public.comments for insert with check (auth.uid() = user_id);
create policy "own comments delete" on public.comments for delete using (auth.uid() = user_id);

create policy "follows readable" on public.follows for select using (true);
create policy "own follows insert" on public.follows for insert with check (auth.uid() = follower_id);
create policy "own follows delete" on public.follows for delete using (auth.uid() = follower_id);

create policy "own notifications readable" on public.notifications for select using (auth.uid() = user_id);
create policy "own notifications update" on public.notifications for update using (auth.uid() = user_id);

-- Storage bucket for profile/post media.
insert into storage.buckets (id, name, public)
values ('rpgram-media', 'rpgram-media', true)
on conflict (id) do nothing;